
//{{BLOCK(dodge)

//======================================================================
//
//	dodge, 28x24@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 672 = 1184
//
//	Time-stamp: 2023-03-02, 14:37:06
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_DODGE_H
#define GRIT_DODGE_H

#define dodgeBitmapLen 672
extern const unsigned short dodgeBitmap[336];

#define dodgePalLen 512
extern const unsigned short dodgePal[256];

#endif // GRIT_DODGE_H

//}}BLOCK(dodge)
