# SONIC!
This is my bootleg version of a Sonic obstacle course game.
# Instructions
The rules are simple! Get to the other side as fast as possible. You start with 3 lives, and you lose one each time you touch a bullet or the moving rectangle (pretend it's Eggman).

If you get to the other side, you win! 
The bullets can't reach you from your starting position... but you're just embarrassing yourself if you stay there.

If you lose all lives... you uh..

>! You lose! (Your score won't get counted, because you failed).

That wasn't so hard to figure out now was it?!

# Player Controls
UP - Move the player up
DOWN - Move the player down
LEFT - Move the player left
RIGHT - Move the player right

RSHOULDER and LSHOULDER both make your player enter a dodge state for about a second
> The dodge state has a cooldown of 5 seconds.
'SELECT' and 'START' are navigation tools 
# Navigation
You can navigate the state machine by pressing certain buttons:

## Start Screen Navigation
Press 'START' to start the game.
## GAME Screen Navigation
Press 'START' to pause the game.

## PAUSE Screen Navigation
Press 'SELECT' to go to the scoreboard.
Press 'START' to resume the game.

## Scoreboard Screen Navigation
Press 'START' to go back to the pause screen, where you can press 'START' again to resume your game.

## WIN/LOSE Screen Navigation
Press 'START' to go back to the start screen.

## Uncompleted features
The moving block is supposed to be eggman, but for the sake of time, it's just a moving rectangle.


